rm Makefile
cp makefiles/Makefile.ZLIB Makefile
make clean
make
