./fetch_install_omegaplus.sh
./fetch_install_raisd.sh
./fetch_install_sweed.sh
./fetch_install_sweepfinder.sh
./fetch_install_sweepfinder2.sh
