rm -r chr$1
